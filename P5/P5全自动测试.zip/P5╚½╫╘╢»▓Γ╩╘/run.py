import os
os.system("main.py > 结果.txt")
